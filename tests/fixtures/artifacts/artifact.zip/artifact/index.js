exports.handler = function (event, context, callback) {
  // Handle both Buffer (Aliyun FC) and direct object (AWS Lambda)
  var eventData;
  if (Buffer.isBuffer(event)) {
    // Aliyun FC format: event is a Buffer
    eventData = JSON.parse(event.toString());
    
    // Log using context.logger if available (Aliyun FC)
    if (context && context.logger) {
      context.logger.info('Processing Aliyun FC request');
    }
    
    console.log('ServerlessInsight Hello World');
    
    // Return Aliyun FC response format
    var response = {
      isBase64Encoded: false,
      statusCode: '200',
      headers: {
        'Content-Type': 'text/plain'
      },
      body: 'ServerlessInsight Hello World'
    };
    callback(null, response);
  } else {
    // AWS Lambda format: event is an object
    console.log('ServerlessInsight Hello World');
    callback(null, 'ServerlessInsight Hello World');
  }
};
