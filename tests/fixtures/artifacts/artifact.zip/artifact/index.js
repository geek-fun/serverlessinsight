exports.handler = function (event, context, callback) {
  console.log('ServerlessInsight Hello World');
  callback(null, 'ServerlessInsight Hello World');
};
